  
// API key
const API_KEY = "pk.eyJ1IjoicmZhcjAwMDEiLCJhIjoiY2thNGtucm5rMTJlZjNucXk5bTRxYXg5dyJ9.yPnm5bUBE6nr-AGSpbYc4g";